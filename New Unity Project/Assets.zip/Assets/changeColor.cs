﻿using UnityEngine;
using System.Collections;

public class changeColor : MonoBehaviour {
	public GameObject finger;
	public GameObject finger2;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if ((finger.transform.position.x>0 && finger.transform.position.y > -0.2 && finger.transform.position.y < 0)||
		    (finger2.transform.position.x>0 && finger2.transform.position.y > -0.2 && finger2.transform.position.y<0)) {
						renderer.material.color = new Color (1, 0, 0);
				} else {
						renderer.material.color = new Color (1, 1, 1);
				}
	}
}
