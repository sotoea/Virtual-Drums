﻿using UnityEngine;
using System.Collections;
using System.IO;


public class Snare : MonoBehaviour {
	public AudioClip snare;
	public AudioClip snare2;
	private bool played = false;
	private int hit = 0;

	// Use this for initialization
	void Start () {


	}

	// Update is called once per frame
	void Update () {

		if (transform.position.z < 0.25 && transform.position.z > 0 && 
		    transform.position.x < 0.25 && transform.position.x > 0 && 
		    transform.position.y > -0.2 && transform.position.y < 0 && 
		    played == false) {
			audio.PlayOneShot (snare);
			played = true;
			StreamWriter writetext = new StreamWriter(hit.ToString()+".txt");
			writetext.WriteLine(transform.position.x.ToString());
			writetext.WriteLine(transform.position.z.ToString());
			writetext.WriteLine(Time.timeSinceLevelLoad);
			writetext.Close();
			hit++;


		} else if((transform.position.z < 0.25 && transform.position.z > 0 && 
		           transform.position.x >-0.25 && transform.position.x < 0 && 
		           transform.position.y > -0.2 && transform.position.y < 0 && 
		           played == false)) {
			audio.PlayOneShot (snare2);
			played = true;
		} else if (transform.position.y >= 0) {
			played = false;
		}


	}
}
