﻿using UnityEngine;
using System.Collections;

public class changeColor2 : MonoBehaviour {
	public GameObject finger11;
	public GameObject finger22;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if ((finger11.transform.position.x<0 &&finger11.transform.position.y > -0.2 && finger11.transform.position.y < 0)||
		    (finger22.transform.position.x<0 &&finger22.transform.position.y > -0.2 && finger22.transform.position.y<0)) {
			renderer.material.color = new Color (0, 0, 1);
		} else {
			renderer.material.color = new Color (1, 1, 1);
		}
	}
}
