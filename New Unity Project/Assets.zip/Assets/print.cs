﻿using UnityEngine;
using System.Collections;

public class print : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	//	print (transform.position);
	}
}
